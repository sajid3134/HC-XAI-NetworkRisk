SecureSpeak — Paper 1 — Elsevier (elsarticle) format
=====================================================
For: Cyber Security and Applications (KeAi/Elsevier)

SAME PAPER as the ACM DTRAP version — identical content, numbers, and framing.
ONLY the template changed (acmart -> elsarticle).

HOW TO USE (Overleaf):
1. overleaf.com -> New Project -> Blank Project (or Upload Project).
2. Upload main_elsevier.tex (rename to main.tex if you like) + fig1_architecture.png.
3. Compiler: pdfLaTeX (Menu -> Compiler). elsarticle is built into Overleaf.
4. Recompile.

BEFORE SUBMITTING — check the journal's Guide for Authors for:
  - Whether they require "Highlights" (3-5 short bullet points, <=85 chars each)
  - Whether they require a "Graphical Abstract"
  - Exact reference style (this uses numbered [1],[2]... which is standard)
  - Cover letter + declarations (competing interest + data availability are already
    included at the end of the paper; a separate cover letter is usually also needed)

The author block, corresponding author, affiliations, and all 21 references are set.
Author order: Khondokar Sajid (corresponding), Abdul Alim Rakib, Nova Ahmed.

DO NOT SUBMIT until Dr. Nova Ahmed approves.
